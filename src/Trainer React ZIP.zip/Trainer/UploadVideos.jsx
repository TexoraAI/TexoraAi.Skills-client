import { useEffect, useRef, useState } from "react";
import videoService from "../services/videoService";
import { courseService } from "../services/courseService";
import VideoList from "./VideoList";
import UploadDocuments from "./UploadDocuments";
import CreateQuiz from "./CreateQuiz";
import CreateAssignments from "./CreateAssignments";
import UsageBadge from "../components/plan/UsageBadge";
import UpgradeModal from "../components/plan/UpgradeModal";
import { parsePlanError } from "../services/planErrorHandler";
import {
  UploadCloud,
  Video,
  FileText,
  ClipboardEdit,
  BookOpen,
  Link,
  ChevronDown,
  Eye,
  Lock,
  Globe,
  Send,
  Save,
  X,
  Check,
  Search,
  Plus,
} from "lucide-react";
// ─── Global Design System — single source of truth for colors, type,
// spacing, radius, StatCard, PageContainer and Hero. This page reuses the
// same tokens as the Trainer Dashboard (Golden Reference) instead of
// redeclaring page-specific styles. Hero typography now pulls FONT_SIZE /
// LINE_HEIGHT / LETTER_SPACING the same way the Attendance page (Golden
// Reference) does, instead of hardcoded clamp()/px values.
import {
  T,
  FONT_FAMILY,
  FONT_WEIGHT,
  FONT_SIZE,
  LINE_HEIGHT,
  LETTER_SPACING,
  RADIUS,
  CARD_PADDING,
  ACCENT_PURPLE,
  PageContainer,
  Hero,
} from "@/design-system";

/* ─────────────────── FONT (Golden Reference typography) ─────────────────── */
const FF = FONT_FAMILY;

const getAuthTokenUserId = () => {
  try {
    const token = localStorage.getItem("lms_token");
    if (!token) return null;
    return JSON.parse(atob(token.split(".")[1]))?.userId ?? null;
  } catch {
    return null;
  }
};

/* ─────────────────── THEME COLOR MAP — derived from the shared design
   token set (T.dark / T.light) so this page matches the Trainer Dashboard's
   palette exactly instead of keeping its own one-off hex values. Field
   names are preserved so the rest of this file (which already consumes
   `c.xxx` everywhere) needs no further changes. ─────────────────── */
const getColors = (isDark) => {
  const t = isDark ? T.dark : T.light;
  return {
    cardBg: t.cardBg,
    cardBorder: t.border,
    inputBg: isDark ? t.pillBg : t.iconBg,
    inputBorder: t.border,
    textPrimary: t.text,
    textSub: t.textSub,
    textMuted: t.textMuted,
    accent: ACCENT_PURPLE.base,
    accentBg: isDark ? "rgba(124,58,237,0.14)" : "rgba(124,58,237,0.08)",
    accentLight: isDark ? "rgba(124,58,237,0.1)" : "rgba(124,58,237,0.06)",
    divider: t.border,
    hoverBg: t.cardBgHov,
    successColor: t.liveText,
    errorColor: t.overdueText,
    toggleOff: t.textMuted,
    zeroBg: t.emptyBg,
    draftColor: t.newBadgeText,
    draftBg: t.newBadgeBg,
    draftBorder: t.newBadgeBorder,
    shadow: t.shadow,
  };
};

const lbl = (c) => ({
  fontSize: 12,
  fontWeight: FONT_WEIGHT.medium || 500,
  color: c.textSub,
  marginBottom: 6,
  fontFamily: FF,
  display: "block",
});
const inp = (c) => ({
  width: "100%",
  padding: "10px 14px",
  border: `1px solid ${c.inputBorder}`,
  borderRadius: RADIUS.button,
  background: c.inputBg,
  color: c.textPrimary,
  fontSize: 14,
  outline: "none",
  fontFamily: FF,
  boxSizing: "border-box",
  transition: "border-color .15s",
});
const pBtn = () => ({
  padding: "9px 20px",
  borderRadius: RADIUS.button,
  border: "none",
  background: ACCENT_PURPLE.base,
  color: "#fff",
  fontSize: 13,
  fontWeight: FONT_WEIGHT.bold,
  cursor: "pointer",
  fontFamily: FF,
});
const oBtn = (c) => ({
  padding: "9px 20px",
  borderRadius: RADIUS.button,
  border: `1px solid ${c.inputBorder}`,
  background: c.cardBg,
  color: c.textPrimary,
  fontSize: 13,
  fontWeight: FONT_WEIGHT.bold,
  cursor: "pointer",
  fontFamily: FF,
});
const dkBtn = (c) => ({
  padding: "9px 22px",
  borderRadius: RADIUS.pill,
  border: "none",
  background: c.textPrimary,
  color: c.cardBg,
  fontSize: 14,
  fontWeight: FONT_WEIGHT.bold,
  cursor: "pointer",
  fontFamily: FF,
});

/* ── "default_segment" → null for API payloads ── */
const resolveBatchId = (batchId) => {
  if (!batchId || batchId === "default_segment") return null;
  return batchId;
};

/* ─────────────────── URL → EMBED CONVERTER ─────────────────── */
const parseVideoUrl = (rawUrl) => {
  if (!rawUrl || !rawUrl.trim()) return null;
  const url = rawUrl.trim();

  const ytWatch = url.match(
    /(?:youtube\.com\/watch\?(?:.*&)?v=|youtu\.be\/)([\w-]{11})/,
  );
  const ytShorts = url.match(/youtube\.com\/shorts\/([\w-]{11})/);
  const ytEmbed = url.match(/youtube\.com\/embed\/([\w-]{11})/);

  if (ytWatch || ytShorts || ytEmbed) {
    const id = (ytWatch || ytShorts || ytEmbed)[1];
    return {
      type: "iframe",
      url: `https://www.youtube.com/embed/${id}?rel=0&modestbranding=1`,
    };
  }

  const vimeo = url.match(/(?:vimeo\.com\/(?:video\/)?)(\d+)/);
  if (vimeo)
    return {
      type: "iframe",
      url: `https://player.vimeo.com/video/${vimeo[1]}`,
    };

  if (/\.(mp4|webm|ogg|mov|m4v)(\?.*)?$/i.test(url))
    return { type: "video", url };
  return { type: "video", url };
};

/* ─────────────────── VIDEO PREVIEW PLAYER ─────────────────── */
const VideoPreviewPlayer = ({ file, videoUrl, style = {} }) => {
  const defaultStyle = {
    width: "100%",
    borderRadius: 4,
    background: "#000",
    aspectRatio: "16/9",
    objectFit: "contain",
    border: "none",
    ...style,
  };

  if (file)
    return (
      <video src={URL.createObjectURL(file)} style={defaultStyle} controls />
    );

  if (videoUrl && videoUrl.trim()) {
    const parsed = parseVideoUrl(videoUrl);
    if (parsed) {
      if (parsed.type === "iframe") {
        return (
          <iframe
            src={parsed.url}
            style={defaultStyle}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            title="Video preview"
          />
        );
      }
      return <video src={parsed.url} style={defaultStyle} controls />;
    }
  }

  return (
    <div
      style={{
        ...defaultStyle,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Video size={28} color="#555" />
    </div>
  );
};

/* ─────────────────── STEP PROGRESS BAR ─────────────────── */
const StepProgressBar = ({ activeStep, setActiveStep, c }) => {
  const steps = [
    { key: 1, label: "Details" },
    { key: 2, label: "Video elements" },
    { key: 3, label: "Checks" },
    { key: 4, label: "Visibility" },
  ];
  return (
    <div
      className="uv-step-progress"
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "0 32px",
        overflowX: "auto",
      }}
    >
      {steps.map((step, i) => {
        const isActive = activeStep === step.key;
        const isDone = activeStep > step.key;
        return (
          <div
            key={step.key}
            style={{
              display: "flex",
              alignItems: "center",
              flex: i < steps.length - 1 ? 1 : "none",
            }}
          >
            <div
              onClick={() => setActiveStep(step.key)}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                cursor: "pointer",
                minWidth: 80,
              }}
            >
              <div
                style={{
                  width: 28,
                  height: 28,
                  borderRadius: "50%",
                  border: `2px solid ${isActive || isDone ? c.accent : c.textMuted}`,
                  background: isActive || isDone ? c.accent : c.cardBg,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: 6,
                  transition: "all .2s",
                }}
              >
                {isDone ? (
                  <Check size={13} color="#fff" strokeWidth={3} />
                ) : (
                  <span
                    style={{
                      fontSize: 12,
                      fontWeight: 700,
                      color: isActive ? "#fff" : c.textMuted,
                      fontFamily: FF,
                    }}
                  >
                    {step.key}
                  </span>
                )}
              </div>
              <span
                style={{
                  fontSize: 12,
                  fontWeight: isActive ? 600 : 400,
                  color: isActive || isDone ? c.accent : c.textSub,
                  fontFamily: FF,
                  whiteSpace: "nowrap",
                }}
              >
                {step.label}
              </span>
            </div>
            {i < steps.length - 1 && (
              <div
                style={{
                  flex: 1,
                  height: 1,
                  background: isDone ? c.accent : c.divider,
                  margin: "0 4px",
                  marginBottom: 20,
                  transition: "background .2s",
                }}
              />
            )}
          </div>
        );
      })}
    </div>
  );
};

/* ─────────────────── MODAL ─────────────────── */
const Modal = ({ title, onClose, children, c }) => (
  <div
    style={{
      position: "fixed",
      inset: 0,
      zIndex: 99999,
      background: "rgba(0,0,0,0.65)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 20,
    }}
    onClick={onClose}
  >
    <div
      onClick={(e) => e.stopPropagation()}
      style={{
        background: c.cardBg,
        borderRadius: 6,
        width: "100%",
        maxWidth: 500,
        border: `1px solid ${c.cardBorder}`,
        boxShadow: "0 12px 48px rgba(0,0,0,0.4)",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "18px 24px 14px",
          borderBottom: `1px solid ${c.divider}`,
        }}
      >
        <div
          style={{
            fontSize: 16,
            fontWeight: 600,
            color: c.textPrimary,
            fontFamily: FF,
          }}
        >
          {title}
        </div>
        <div
          onClick={onClose}
          style={{
            cursor: "pointer",
            color: c.textSub,
            display: "flex",
            padding: 4,
            borderRadius: "50%",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.background = c.hoverBg)}
          onMouseLeave={(e) =>
            (e.currentTarget.style.background = "transparent")
          }
        >
          <X size={18} />
        </div>
      </div>
      <div
        style={{
          padding: "18px 24px 22px",
          overflowY: "auto",
          maxHeight: "80vh",
        }}
      >
        {children}
      </div>
    </div>
  </div>
);

/* ─────────────────── SUBTITLE MODAL ─────────────────── */
const SubtitleModal = ({ onClose, onSave, c }) => {
  const [file, setFile] = useState(null);
  const [lang, setLang] = useState("English");
  const fileRef = useRef();
  return (
    <Modal title="Add Subtitles / Captions" onClose={onClose} c={c}>
      <div style={{ marginBottom: 14 }}>
        <label style={lbl(c)}>Language</label>
        <select
          value={lang}
          onChange={(e) => setLang(e.target.value)}
          style={{ ...inp(c), appearance: "none", cursor: "pointer" }}
        >
          {["English", "Hindi", "Bengali", "Tamil", "Telugu"].map((l) => (
            <option
              key={l}
              value={l}
              style={{ background: c.cardBg, color: c.textPrimary }}
            >
              {l}
            </option>
          ))}
        </select>
      </div>
      <div style={{ marginBottom: 18 }}>
        <label style={lbl(c)}>Subtitle File (.srt / .vtt)</label>
        <label
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 10,
            padding: 28,
            border: `2px dashed ${file ? c.accent : c.inputBorder}`,
            borderRadius: 4,
            background: file ? c.accentLight : c.zeroBg,
            cursor: "pointer",
          }}
        >
          <FileText size={28} color={file ? c.accent : c.textMuted} />
          {file ? (
            <span
              style={{
                fontSize: 13,
                fontWeight: 600,
                color: c.accent,
                fontFamily: FF,
              }}
            >
              ✓ {file.name}
            </span>
          ) : (
            <>
              <span
                style={{
                  fontSize: 13,
                  fontWeight: 500,
                  color: c.textPrimary,
                  fontFamily: FF,
                }}
              >
                Click to upload subtitle file
              </span>
              <span style={{ fontSize: 11, color: c.textSub, fontFamily: FF }}>
                .SRT or .VTT supported
              </span>
            </>
          )}
          <input
            ref={fileRef}
            type="file"
            accept=".srt,.vtt"
            hidden
            onChange={(e) => setFile(e.target.files[0])}
          />
        </label>
      </div>
      <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
        <button onClick={onClose} style={oBtn(c)}>
          Cancel
        </button>
        <button
          onClick={() => {
            onSave({ file, lang });
            onClose();
          }}
          style={pBtn()}
        >
          Add Subtitles
        </button>
      </div>
    </Modal>
  );
};

/* ─────────────────── END SCREEN MODAL ─────────────────── */
const EndScreenModal = ({ onClose, onSave, c }) => {
  const [selected, setSelected] = useState(null);
  const templates = [
    {
      id: "related",
      label: "Related Video",
      desc: "Suggest another lecture at end",
    },
    {
      id: "subscribe",
      label: "Subscribe Prompt",
      desc: "Encourage course enrollment",
    },
    {
      id: "playlist",
      label: "Course Playlist",
      desc: "Show the full course playlist",
    },
    {
      id: "custom",
      label: "Custom Link",
      desc: "Redirect to any URL after video",
    },
  ];
  return (
    <Modal title="Add End Screen" onClose={onClose} c={c}>
      <p
        style={{
          fontSize: 13,
          color: c.textSub,
          fontFamily: FF,
          marginBottom: 14,
          marginTop: 0,
        }}
      >
        Choose a template to show in the last 20 seconds of your lecture
      </p>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 10,
          marginBottom: 18,
        }}
      >
        {templates.map((tpl) => (
          <div
            key={tpl.id}
            onClick={() => setSelected(tpl.id)}
            style={{
              padding: "13px 15px",
              borderRadius: 4,
              cursor: "pointer",
              border:
                selected === tpl.id
                  ? `2px solid ${c.accent}`
                  : `1px solid ${c.inputBorder}`,
              background: selected === tpl.id ? c.accentLight : c.inputBg,
            }}
          >
            <div
              style={{
                fontSize: 13,
                fontWeight: 600,
                color: selected === tpl.id ? c.accent : c.textPrimary,
                fontFamily: FF,
                marginBottom: 3,
              }}
            >
              {tpl.label}
            </div>
            <div style={{ fontSize: 12, color: c.textSub, fontFamily: FF }}>
              {tpl.desc}
            </div>
          </div>
        ))}
      </div>
      <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
        <button onClick={onClose} style={oBtn(c)}>
          Cancel
        </button>
        <button
          disabled={!selected}
          onClick={() => {
            onSave(selected);
            onClose();
          }}
          style={{
            ...pBtn(),
            opacity: selected ? 1 : 0.5,
            cursor: selected ? "pointer" : "not-allowed",
          }}
        >
          Add End Screen
        </button>
      </div>
    </Modal>
  );
};

/* ─────────────────── CARDS MODAL ─────────────────── */
const CardsModal = ({ onClose, onSave, c }) => {
  const [type, setType] = useState("video");
  const [url, setUrl] = useState("");
  const [label, setLabel] = useState("");
  return (
    <Modal title="Add Card" onClose={onClose} c={c}>
      <div
        style={{
          display: "flex",
          marginBottom: 16,
          borderBottom: `1px solid ${c.divider}`,
        }}
      >
        {[
          { key: "video", label: "Video Card" },
          { key: "link", label: "Link Card" },
        ].map(({ key, label: lbl_ }) => (
          <button
            key={key}
            onClick={() => setType(key)}
            style={{
              padding: "9px 16px",
              border: "none",
              cursor: "pointer",
              fontFamily: FF,
              fontSize: 13,
              fontWeight: type === key ? 600 : 400,
              background: "transparent",
              color: type === key ? c.accent : c.textSub,
              borderBottom:
                type === key
                  ? `2px solid ${c.accent}`
                  : "2px solid transparent",
              marginBottom: -1,
            }}
          >
            {lbl_}
          </button>
        ))}
      </div>
      <div style={{ marginBottom: 14 }}>
        <label style={lbl(c)}>
          {type === "video" ? "Video / Lecture URL" : "External Link URL"}
        </label>
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder={type === "video" ? "https://..." : "https://example.com"}
          style={inp(c)}
          onFocus={(e) => (e.target.style.borderColor = c.accent)}
          onBlur={(e) => (e.target.style.borderColor = c.inputBorder)}
        />
      </div>
      <div style={{ marginBottom: 18 }}>
        <label style={lbl(c)}>Card Label (shown to students)</label>
        <input
          type="text"
          value={label}
          onChange={(e) => setLabel(e.target.value)}
          placeholder="e.g. Watch next: React Hooks"
          style={inp(c)}
          onFocus={(e) => (e.target.style.borderColor = c.accent)}
          onBlur={(e) => (e.target.style.borderColor = c.inputBorder)}
        />
      </div>
      <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
        <button onClick={onClose} style={oBtn(c)}>
          Cancel
        </button>
        <button
          disabled={!url.trim()}
          onClick={() => {
            onSave({ type, url, label });
            onClose();
          }}
          style={{
            ...pBtn(),
            opacity: url.trim() ? 1 : 0.5,
            cursor: url.trim() ? "pointer" : "not-allowed",
          }}
        >
          Add Card
        </button>
      </div>
    </Modal>
  );
};

/* ─────────────────── CUSTOM SELECT ─────────────────── */
const CustomSelect = ({
  value,
  onChange,
  options,
  placeholder = "Select...",
  c,
}) => {
  const [open, setOpen] = useState(false);
  const ref = useRef();
  useEffect(() => {
    const close = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);
  const sel = options.find((o) => (o.value ?? o) === value);
  const display = sel ? (sel.label ?? sel) : null;
  return (
    <div ref={ref} style={{ position: "relative", width: "100%" }}>
      <div
        onClick={() => setOpen((p) => !p)}
        style={{
          ...inp(c),
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          cursor: "pointer",
          userSelect: "none",
          color: display ? c.textPrimary : c.textMuted,
        }}
      >
        <span style={{ fontSize: 14, fontFamily: FF }}>
          {display ?? placeholder}
        </span>
        <ChevronDown
          size={16}
          color={c.textSub}
          style={{
            transform: open ? "rotate(180deg)" : "none",
            transition: "transform .2s",
          }}
        />
      </div>
      {open && (
        <div
          style={{
            position: "fixed",
            zIndex: 99999,
            background: c.cardBg,
            border: `1px solid ${c.inputBorder}`,
            borderRadius: 4,
            overflow: "hidden",
            boxShadow: "0 6px 24px rgba(0,0,0,0.35)",
            maxHeight: 220,
            overflowY: "auto",
            width: ref.current ? ref.current.offsetWidth : "auto",
            top: ref.current
              ? ref.current.getBoundingClientRect().bottom + 2
              : "auto",
            left: ref.current
              ? ref.current.getBoundingClientRect().left
              : "auto",
          }}
        >
          {options.map((opt) => {
            const val = opt.value ?? opt,
              lbl_ = opt.label ?? opt,
              isSel = val === value;
            return (
              <div
                key={val}
                onClick={() => {
                  onChange(val);
                  setOpen(false);
                }}
                style={{
                  padding: "10px 14px",
                  fontSize: 14,
                  fontFamily: FF,
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  color: isSel ? c.accent : c.textPrimary,
                  background: isSel ? c.accentBg : "transparent",
                }}
                onMouseEnter={(e) => {
                  if (!isSel) e.currentTarget.style.background = c.hoverBg;
                }}
                onMouseLeave={(e) => {
                  if (!isSel) e.currentTarget.style.background = "transparent";
                }}
              >
                {lbl_}
                {isSel && <Check size={14} color={c.accent} />}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

/* ─────────────────── SEARCHABLE SELECT ─────────────────── */
const SearchableSelect = ({
  value,
  onChange,
  options = [],
  placeholder = "Search or select…",
  onAdd,
  loading = false,
  c,
}) => {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const wrapRef = useRef(null);
  const inputRef = useRef(null);

  const norm = options.map((o) =>
    typeof o === "string" ? { value: o, label: o } : o,
  );
  const selectedLabel = norm.find((o) => o.value === value)?.label ?? null;
  const q = query.trim().toLowerCase();
  const filtered = q
    ? norm.filter((o) => o.label.toLowerCase().includes(q))
    : norm;
  const exactMatch = norm.some((o) => o.label.toLowerCase() === q);

  useEffect(() => {
    const h = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) {
        setOpen(false);
        setQuery("");
      }
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 40);
  }, [open]);

  const select = (val) => {
    onChange(val);
    setOpen(false);
    setQuery("");
  };
  const useCustom = () => {
    if (!query.trim()) return;
    onChange(query.trim());
    setOpen(false);
    setQuery("");
  };
  const clearValue = (e) => {
    e.stopPropagation();
    onChange("");
    setQuery("");
  };

  const hl = (text, q) => {
    if (!q) return text;
    const idx = text.toLowerCase().indexOf(q.toLowerCase());
    if (idx === -1) return text;
    return (
      <>
        {text.slice(0, idx)}
        <mark
          style={{
            background: c.accentBg,
            color: c.accent,
            borderRadius: 2,
            padding: "0 1px",
          }}
        >
          {text.slice(idx, idx + q.length)}
        </mark>
        {text.slice(idx + q.length)}
      </>
    );
  };

  return (
    <div ref={wrapRef} style={{ position: "relative", width: "100%" }}>
      <div
        onClick={() => setOpen((p) => !p)}
        style={{
          ...inp(c),
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          cursor: "pointer",
          userSelect: "none",
          color: selectedLabel ? c.textPrimary : c.textMuted,
          borderColor: open ? c.accent : c.inputBorder,
          borderRadius: open ? "4px 4px 0 0" : 4,
        }}
      >
        <span
          style={{
            fontSize: 14,
            fontFamily: FF,
            flex: 1,
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
          }}
        >
          {loading ? "Loading courses…" : (selectedLabel ?? placeholder)}
        </span>
        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
          {value && !loading && (
            <span
              onClick={clearValue}
              style={{
                display: "flex",
                alignItems: "center",
                color: c.textSub,
                cursor: "pointer",
              }}
            >
              <X size={13} />
            </span>
          )}
          <ChevronDown
            size={15}
            color={c.textSub}
            style={{
              transform: open ? "rotate(180deg)" : "none",
              transition: "transform .2s",
            }}
          />
        </div>
      </div>

      {open && (
        <div
          style={{
            position: "absolute",
            top: "100%",
            left: 0,
            right: 0,
            zIndex: 99999,
            background: c.cardBg,
            border: `1px solid ${c.accent}`,
            borderTop: "none",
            borderRadius: "0 0 4px 4px",
            boxShadow: "0 6px 24px rgba(0,0,0,0.35)",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              padding: "8px 12px",
              borderBottom: `1px solid ${c.divider}`,
              background: c.zeroBg,
            }}
          >
            <Search size={14} color={c.textSub} />
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && query.trim() && !exactMatch)
                  useCustom();
                if (e.key === "Escape") {
                  setOpen(false);
                  setQuery("");
                }
              }}
              placeholder="Search courses…"
              style={{
                flex: 1,
                border: "none",
                outline: "none",
                background: "transparent",
                color: c.textPrimary,
                fontSize: 14,
                fontFamily: FF,
              }}
            />
          </div>

          <div style={{ maxHeight: 200, overflowY: "auto" }}>
            {loading && (
              <div
                style={{
                  padding: "12px 14px",
                  fontSize: 13,
                  color: c.textSub,
                  fontFamily: FF,
                  textAlign: "center",
                }}
              >
                Loading your courses…
              </div>
            )}

            {!loading && query.trim() && !exactMatch && (
              <div
                onClick={useCustom}
                style={{
                  padding: "10px 14px",
                  fontSize: 13,
                  fontFamily: FF,
                  cursor: "pointer",
                  color: c.accent,
                  fontWeight: 500,
                  background: c.accentLight,
                  borderBottom: `1px solid ${c.divider}`,
                }}
                onMouseEnter={(e) =>
                  (e.currentTarget.style.background = c.accentBg)
                }
                onMouseLeave={(e) =>
                  (e.currentTarget.style.background = c.accentLight)
                }
              >
                + Use &quot;{query.trim()}&quot;
              </div>
            )}

            {!loading &&
              filtered.map((opt) => {
                const isSel = opt.value === value;
                return (
                  <div
                    key={opt.value}
                    onClick={() => select(opt.value)}
                    style={{
                      padding: "10px 14px",
                      fontSize: 14,
                      fontFamily: FF,
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      color: isSel ? c.accent : c.textPrimary,
                      background: isSel ? c.accentBg : "transparent",
                      fontWeight: isSel ? 500 : 400,
                    }}
                    onMouseEnter={(e) => {
                      if (!isSel) e.currentTarget.style.background = c.hoverBg;
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = isSel
                        ? c.accentBg
                        : "transparent";
                    }}
                  >
                    <div style={{ flex: 1, overflow: "hidden" }}>
                      <div
                        style={{
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          whiteSpace: "nowrap",
                        }}
                      >
                        {hl(opt.label, q)}
                      </div>
                      {opt.subtitle && (
                        <div
                          style={{
                            fontSize: 11,
                            color: c.textMuted,
                            fontFamily: FF,
                            marginTop: 2,
                          }}
                        >
                          {opt.subtitle}
                        </div>
                      )}
                    </div>
                    {isSel && <Check size={14} color={c.accent} />}
                  </div>
                );
              })}

            {!loading && filtered.length === 0 && (
              <div
                style={{
                  padding: "10px 14px",
                  fontSize: 13,
                  color: c.textSub,
                  fontFamily: FF,
                  textAlign: "center",
                }}
              >
                {query.trim()
                  ? "Not found — press Enter to use custom"
                  : "No courses found"}
              </div>
            )}
          </div>

          {onAdd && (
            <div
              onClick={() => {
                setOpen(false);
                setQuery("");
                onAdd();
              }}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 6,
                padding: "11px 14px",
                fontSize: 13,
                fontFamily: FF,
                cursor: "pointer",
                color: c.accent,
                borderTop: `1px solid ${c.divider}`,
                fontWeight: 500,
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.background = c.accentLight)
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.background = "transparent")
              }
            >
              <Plus size={14} />
              Add New Course
            </div>
          )}
        </div>
      )}
    </div>
  );
};

/* ─────────────────── TAB CONFIG ─────────────────── */
const TABS = [
  { key: "upload-video", label: "Upload Video", icon: Video },
  { key: "upload-document", label: "Upload Document", icon: FileText },
  { key: "create-quiz", label: "Create Quiz", icon: ClipboardEdit },
  { key: "create-assignment", label: "Create Assignment", icon: BookOpen },
];

/* ─────────────────── VIDEO UPLOAD ZONE ─────────────────── */
const VideoUploadZone = ({
  file,
  setFile,
  setTitle,
  videoUrl,
  setVideoUrl,
  videoType,
  setVideoType,
  c,
}) => {
  const [dragging, setDragging] = useState(false);
  const [progress, setProgress] = useState(0);
  const [uploading, setUploading] = useState(false);
  const [done, setDone] = useState(false);
  const fileRef = useRef();

  const runProgress = () => {
    setUploading(true);
    setDone(false);
    setProgress(0);
    let p = 0;
    const iv = setInterval(() => {
      p = Math.min(p + Math.floor(Math.random() * 12) + 3, 100);
      setProgress(p);
      if (p >= 100) {
        clearInterval(iv);
        setUploading(false);
        setDone(true);
      }
    }, 180);
  };

  const exTitle = (name) =>
    name
      .replace(/\.[^/.]+$/, "")
      .replace(/[_-]/g, " ")
      .replace(/\b\w/g, (ch) => ch.toUpperCase());

  const handleFile = (f) => {
    if (!f || !f.type.startsWith("video/")) return;
    setFile(f);
    setTitle(exTitle(f.name));
    runProgress();
  };

  const tabS = (active) => ({
    padding: "8px 16px",
    border: "none",
    cursor: "pointer",
    fontFamily: FF,
    fontSize: 13,
    fontWeight: active ? 500 : 400,
    background: "transparent",
    color: active ? c.accent : c.textSub,
    borderBottom: active ? `2px solid ${c.accent}` : "2px solid transparent",
    marginBottom: -1,
  });

  const parsedUrl = videoType === "url" ? parseVideoUrl(videoUrl) : null;
  const showUrlPreview = parsedUrl && videoUrl.trim().length > 10;

  return (
    <div>
      <div
        style={{
          display: "flex",
          borderBottom: `1px solid ${c.divider}`,
          marginBottom: 16,
        }}
      >
        <button
          onClick={() => setVideoType("upload")}
          style={tabS(videoType === "upload")}
        >
          <UploadCloud size={13} style={{ marginRight: 5 }} />
          Upload File
        </button>
        <button
          onClick={() => setVideoType("url")}
          style={tabS(videoType === "url")}
        >
          <Link size={13} style={{ marginRight: 5 }} />
          Video URL
        </button>
      </div>

      {videoType === "upload" ? (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);
            handleFile(e.dataTransfer.files[0]);
          }}
          onClick={() => fileRef.current.click()}
          style={{
            border: `2px dashed ${dragging ? c.accent : c.inputBorder}`,
            borderRadius: 4,
            background: dragging ? c.accentLight : c.zeroBg,
            cursor: "pointer",
            transition: "all .2s",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 14,
            minHeight: 200,
            padding: 24,
          }}
        >
          {!file ? (
            <>
              <div
                style={{
                  width: 72,
                  height: 72,
                  borderRadius: "50%",
                  background: c.hoverBg,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <UploadCloud size={32} color={c.textMuted} />
              </div>
              <div style={{ textAlign: "center" }}>
                <div
                  style={{
                    fontSize: 15,
                    fontWeight: 400,
                    color: c.textPrimary,
                    fontFamily: FF,
                    marginBottom: 6,
                  }}
                >
                  Drag and drop video files to upload
                </div>
                <div
                  style={{
                    fontSize: 13,
                    color: c.textSub,
                    fontFamily: FF,
                    marginBottom: 16,
                  }}
                >
                  Your videos will be private until you publish them.
                </div>
                <button
                  style={dkBtn(c)}
                  onClick={(e) => {
                    e.stopPropagation();
                    fileRef.current.click();
                  }}
                >
                  Select files
                </button>
              </div>
            </>
          ) : (
            <>
              <video
                src={URL.createObjectURL(file)}
                style={{
                  width: "100%",
                  borderRadius: 4,
                  maxHeight: 150,
                  objectFit: "contain",
                  background: "#000",
                }}
                controls
              />
              <div
                style={{
                  fontSize: 13,
                  color: c.successColor,
                  fontWeight: 500,
                  fontFamily: FF,
                }}
              >
                ✓ {file.name}
              </div>
            </>
          )}
          <input
            ref={fileRef}
            type="file"
            accept="video/*"
            hidden
            onChange={(e) => handleFile(e.target.files[0])}
          />
        </div>
      ) : (
        <div>
          <label style={lbl(c)}>YouTube / Vimeo / Direct MP4 URL</label>
          <input
            type="text"
            value={videoUrl}
            onChange={(e) => setVideoUrl(e.target.value)}
            placeholder="https://youtube.com/watch?v=... or https://vimeo.com/..."
            style={inp(c)}
            onFocus={(e) => (e.target.style.borderColor = c.accent)}
            onBlur={(e) => (e.target.style.borderColor = c.inputBorder)}
          />
          {showUrlPreview && (
            <div style={{ marginTop: 14 }}>
              <div
                style={{
                  fontSize: 12,
                  color: c.textSub,
                  fontFamily: FF,
                  marginBottom: 8,
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                }}
              >
                <Check size={12} color={c.successColor} />
                <span style={{ color: c.successColor, fontWeight: 500 }}>
                  {parsedUrl.type === "iframe"
                    ? "YouTube/Vimeo embed detected — preview below"
                    : "Direct video URL detected"}
                </span>
              </div>
              <div
                style={{
                  borderRadius: 6,
                  overflow: "hidden",
                  border: `1px solid ${c.cardBorder}`,
                  background: "#000",
                }}
              >
                <VideoPreviewPlayer
                  videoUrl={videoUrl}
                  style={{ maxHeight: 260, borderRadius: 0 }}
                />
              </div>
            </div>
          )}
          {videoUrl.trim().length > 0 && videoUrl.trim().length <= 10 && (
            <div
              style={{
                fontSize: 12,
                color: c.textMuted,
                marginTop: 6,
                fontFamily: FF,
              }}
            >
              Paste a full YouTube, Vimeo, or direct .mp4 URL
            </div>
          )}
        </div>
      )}

      {(uploading || done) && file && (
        <div
          style={{
            marginTop: 12,
            background: c.zeroBg,
            border: `1px solid ${c.cardBorder}`,
            borderRadius: 4,
            padding: "12px 16px",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginBottom: 8,
            }}
          >
            <span
              style={{
                fontSize: 13,
                fontWeight: 500,
                color: c.textPrimary,
                fontFamily: FF,
              }}
            >
              {file.name}
            </span>
            <span
              style={{
                fontSize: 13,
                fontWeight: 500,
                color: c.accent,
                fontFamily: FF,
              }}
            >
              {progress}%
            </span>
          </div>
          <div
            style={{
              height: 3,
              background: c.divider,
              borderRadius: 10,
              overflow: "hidden",
            }}
          >
            <div
              style={{
                height: "100%",
                width: `${progress}%`,
                background: c.accent,
                borderRadius: 10,
                transition: "width .3s",
              }}
            />
          </div>
          <div
            style={{
              fontSize: 12,
              color: c.textSub,
              marginTop: 6,
              fontFamily: FF,
            }}
          >
            {done
              ? "✓ Upload complete"
              : progress < 40
                ? "Checking 0%... 10 minutes left"
                : progress < 80
                  ? "Processing..."
                  : "Almost done..."}
          </div>
        </div>
      )}
    </div>
  );
};

/* ─────────────────── TAG INPUT ─────────────────── */
const TagInput = ({ tags, setTags, c }) => {
  const [val, setVal] = useState("");
  const addTag = (e) => {
    if (e.key !== "Enter") return;
    const v = val.trim();
    if (!v || tags.includes(v)) {
      setVal("");
      return;
    }
    setTags((p) => [...p, v]);
    setVal("");
  };
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        gap: 6,
        padding: "7px 11px",
        border: `1px solid ${c.inputBorder}`,
        borderRadius: 4,
        background: c.inputBg,
        minHeight: 42,
      }}
    >
      {tags.map((tag) => (
        <div
          key={tag}
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 5,
            padding: "3px 9px",
            borderRadius: 3,
            background: c.accentBg,
            color: c.accent,
            fontSize: 12,
            fontWeight: 500,
            fontFamily: FF,
          }}
        >
          {tag}
          <X
            size={10}
            style={{ cursor: "pointer" }}
            onClick={() => setTags((p) => p.filter((tg) => tg !== tag))}
          />
        </div>
      ))}
      <input
        value={val}
        onChange={(e) => setVal(e.target.value)}
        onKeyDown={addTag}
        placeholder={tags.length === 0 ? "Add tag, press Enter..." : ""}
        style={{
          border: "none",
          outline: "none",
          background: "transparent",
          color: c.textPrimary,
          fontSize: 13,
          minWidth: 100,
          flex: 1,
          fontFamily: FF,
        }}
      />
    </div>
  );
};

/* ─────────────────── AUDIENCE CARD ─────────────────── */
const AudienceCard = ({ value, selected, onChange, title, desc, c }) => (
  <label
    onClick={() => onChange(value)}
    style={{
      display: "flex",
      alignItems: "flex-start",
      gap: 12,
      padding: "13px 15px",
      borderRadius: 4,
      cursor: "pointer",
      border: selected ? `2px solid ${c.accent}` : `1px solid ${c.inputBorder}`,
      background: selected ? c.accentLight : c.inputBg,
    }}
  >
    <input
      type="radio"
      checked={selected}
      readOnly
      style={{ marginTop: 2, accentColor: c.accent }}
    />
    <div>
      <div
        style={{
          fontSize: 14,
          fontWeight: 500,
          fontFamily: FF,
          color: c.textPrimary,
        }}
      >
        {title}
      </div>
      <div
        style={{ fontSize: 13, fontFamily: FF, marginTop: 2, color: c.textSub }}
      >
        {desc}
      </div>
    </div>
  </label>
);

/* ─────────────────── VISIBILITY CARD ─────────────────── */
const VisCard = ({ value, selected, onChange, icon: Icon, title, desc, c }) => (
  <label
    onClick={() => onChange(value)}
    style={{
      display: "flex",
      alignItems: "center",
      gap: 14,
      padding: "14px 16px",
      borderRadius: 4,
      cursor: "pointer",
      border: selected ? `2px solid ${c.accent}` : `1px solid ${c.inputBorder}`,
      background: selected ? c.accentLight : c.inputBg,
    }}
  >
    <input
      type="radio"
      checked={selected}
      readOnly
      style={{ accentColor: c.accent }}
    />
    <Icon size={18} color={selected ? c.accent : c.textSub} />
    <div>
      <div
        style={{
          fontSize: 14,
          fontWeight: 500,
          fontFamily: FF,
          color: c.textPrimary,
        }}
      >
        {title}
      </div>
      <div style={{ fontSize: 13, fontFamily: FF, color: c.textSub }}>
        {desc}
      </div>
    </div>
  </label>
);

/* ─────────────────── COURSE CHIP ─────────────────── */
const CourseChip = ({ label, c }) => {
  const [active, setActive] = useState(false);
  return (
    <div
      onClick={() => setActive((p) => !p)}
      style={{
        padding: "5px 11px",
        borderRadius: 3,
        cursor: "pointer",
        border: active
          ? `1.5px solid ${c.accent}`
          : `1px solid ${c.inputBorder}`,
        background: active ? c.accentBg : c.zeroBg,
        color: active ? c.accent : c.textSub,
        fontSize: 12,
        fontWeight: active ? 500 : 400,
        fontFamily: FF,
        display: "inline-flex",
        alignItems: "center",
        gap: 5,
      }}
    >
      {active && <Check size={10} />}
      {label}
    </div>
  );
};

/* ─────────────────── SECTION TITLE ─────────────────── */
const SecTitle = ({ title, subtitle, c }) => (
  <div style={{ marginBottom: 18 }}>
    <h3
      style={{
        fontSize: 16,
        fontWeight: 600,
        color: c.textPrimary,
        fontFamily: FF,
        margin: "0 0 4px",
      }}
    >
      {title}
    </h3>
    {subtitle && (
      <p style={{ fontSize: 13, color: c.textSub, fontFamily: FF, margin: 0 }}>
        {subtitle}
      </p>
    )}
  </div>
);

const Divider = ({ c }) => (
  <div style={{ height: 1, background: c.divider, margin: "22px 0" }} />
);

const CATEGORIES = [
  "Education",
  "Technology",
  "Programming",
  "Design",
  "Data Science",
  "Business",
  "Mathematics",
];
const LANGUAGES = [
  "English",
  "Hindi",
  "Bengali",
  "Tamil",
  "Telugu",
  "Marathi",
  "Gujarati",
];

/* ─────────────────── STEP 1: DETAILS ─────────────────── */
const StepDetails = ({
  file,
  setFile,
  title,
  setTitle,
  videoUrl,
  setVideoUrl,
  videoType,
  setVideoType,
  shortDesc,
  setShortDesc,
  batchId,
  setBatchId,
  batchOptions,
  tags,
  setTags,
  category,
  setCategory,
  language,
  setLanguage,
  course,
  setCourse,
  courseOptions,
  coursesLoading,
  audience,
  setAudience,
  ageRestrict,
  setAgeRestrict,
  setShowCourseModal,
  c,
}) => (
  <div className="uv-two-col" style={{ display: "flex", gap: 32 }}>
    {/* ── LEFT: main form ── */}
    <div style={{ flex: 1, minWidth: 0 }}>
      <SecTitle title="Details" c={c} />

      <div style={{ marginBottom: 18 }}>
        <label style={lbl(c)}>Video Upload</label>
        <VideoUploadZone
          file={file}
          setFile={setFile}
          setTitle={setTitle}
          videoUrl={videoUrl}
          setVideoUrl={setVideoUrl}
          videoType={videoType}
          setVideoType={setVideoType}
          c={c}
        />
      </div>

      <Divider c={c} />

      <div style={{ marginBottom: 14 }}>
        <label style={lbl(c)}>Title (required)</label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Add a title that describes your video"
          style={inp(c)}
          onFocus={(e) => (e.target.style.borderColor = c.accent)}
          onBlur={(e) => (e.target.style.borderColor = c.inputBorder)}
        />
        <div
          style={{
            fontSize: 11,
            color: c.textMuted,
            textAlign: "right",
            marginTop: 4,
            fontFamily: FF,
          }}
        >
          {title.length}/100
        </div>
      </div>

      <div style={{ marginBottom: 14 }}>
        <label style={lbl(c)}>Description</label>
        <textarea
          rows={4}
          value={shortDesc}
          onChange={(e) => setShortDesc(e.target.value)}
          placeholder="Tell viewers about your video"
          style={{ ...inp(c), resize: "vertical" }}
          onFocus={(e) => (e.target.style.borderColor = c.accent)}
          onBlur={(e) => (e.target.style.borderColor = c.inputBorder)}
        />
      </div>

      <div
        className="uv-form-grid-2"
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 14,
          marginBottom: 14,
        }}
      >
        <div>
          <label style={lbl(c)}>Category</label>
          <CustomSelect
            value={category}
            onChange={setCategory}
            options={CATEGORIES}
            placeholder="Select Category"
            c={c}
          />
        </div>
        <div>
          <label style={lbl(c)}>Language</label>
          <CustomSelect
            value={language}
            onChange={setLanguage}
            options={LANGUAGES}
            c={c}
          />
        </div>
      </div>

      {/* ── Batch Select ── */}
      <div
        className="uv-form-grid-2"
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 14,
          marginBottom: 14,
        }}
      >
        <div>
          <label style={lbl(c)}>Select Batch</label>
          <CustomSelect
            value={batchId}
            onChange={setBatchId}
            options={batchOptions}
            placeholder="Select Batch"
            c={c}
          />
          {batchId === "default_segment" && (
            <p
              style={{
                margin: "5px 0 0",
                fontSize: 11,
                fontFamily: FF,
                color: c.draftColor,
              }}
            >
              ⚠ No batch selected — video will not be visible to students until
              you assign a batch.
            </p>
          )}
        </div>
        <div>
          <label style={lbl(c)}>Tags</label>
          <TagInput tags={tags} setTags={setTags} c={c} />
        </div>
      </div>

      <Divider c={c} />

      <div style={{ marginBottom: 14 }}>
        <label style={lbl(c)}>Course / Playlist</label>
        <SearchableSelect
          value={course}
          onChange={setCourse}
          options={courseOptions}
          placeholder="Map to a course…"
          onAdd={() => setShowCourseModal(true)}
          loading={coursesLoading}
          c={c}
        />
      </div>

      <div style={{ marginBottom: 14 }}>
        <label style={lbl(c)}>Also Add To (multi-select)</label>
        <div
          style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 4 }}
        >
          {courseOptions.length === 0 && !coursesLoading && (
            <span style={{ fontSize: 12, color: c.textMuted, fontFamily: FF }}>
              No courses found
            </span>
          )}
          {coursesLoading && (
            <span style={{ fontSize: 12, color: c.textMuted, fontFamily: FF }}>
              Loading…
            </span>
          )}
          {courseOptions.map((cr) => (
            <CourseChip key={cr.value} label={cr.label} c={c} />
          ))}
        </div>
      </div>

      <Divider c={c} />

      <div style={{ marginBottom: 14 }}>
        <label style={lbl(c)}>Audience</label>
        <p
          style={{
            fontSize: 13,
            color: c.textSub,
            fontFamily: FF,
            marginBottom: 10,
            marginTop: 0,
          }}
        >
          Is this video made for kids? (required)
        </p>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <AudienceCard
            value="kids"
            selected={audience === "kids"}
            onChange={setAudience}
            title="Yes, it's made for kids"
            desc="Appropriate for children"
            c={c}
          />
          <AudienceCard
            value="not-kids"
            selected={audience === "not-kids"}
            onChange={setAudience}
            title="No, it's not made for kids"
            desc="General audience content"
            c={c}
          />
        </div>
      </div>

      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "13px 15px",
          border: `1px solid ${c.inputBorder}`,
          borderRadius: 4,
          background: c.zeroBg,
        }}
      >
        <div>
          <div
            style={{
              fontSize: 14,
              fontWeight: 500,
              color: c.textPrimary,
              fontFamily: FF,
            }}
          >
            Age Restriction (18+)
          </div>
          <div
            style={{
              fontSize: 13,
              color: c.textSub,
              fontFamily: FF,
              marginTop: 2,
            }}
          >
            Restrict to adults only
          </div>
        </div>
        <div
          onClick={() => setAgeRestrict((p) => !p)}
          style={{
            width: 44,
            height: 24,
            borderRadius: 12,
            cursor: "pointer",
            position: "relative",
            transition: "background .2s",
            flexShrink: 0,
            backgroundColor: ageRestrict ? c.accent : c.toggleOff,
          }}
        >
          <div
            style={{
              width: 20,
              height: 20,
              borderRadius: "50%",
              background: "#fff",
              position: "absolute",
              top: 2,
              left: ageRestrict ? 22 : 2,
              transition: "left .2s",
              boxShadow: "0 1px 4px rgba(0,0,0,.3)",
            }}
          />
        </div>
      </div>
    </div>

    {/* ── RIGHT: sticky preview sidebar ── */}
    <div className="uv-side-panel" style={{ width: 230, flexShrink: 0 }}>
      <div style={{ position: "sticky", top: 16 }}>
        <div
          style={{
            borderRadius: 4,
            overflow: "hidden",
            marginBottom: 12,
            background: "#000",
            aspectRatio: "16/9",
          }}
        >
          <VideoPreviewPlayer
            file={file}
            videoUrl={videoType === "url" ? videoUrl : ""}
            style={{ borderRadius: 0 }}
          />
        </div>
        {(file || videoUrl) && (
          <div
            style={{
              fontSize: 12,
              color: c.textSub,
              fontFamily: FF,
              marginBottom: 10,
            }}
          >
            <div
              style={{
                fontWeight: 600,
                color: c.textPrimary,
                marginBottom: 3,
                fontSize: 12,
              }}
            >
              {videoType === "url" ? "Video URL" : "Video link"}
            </div>
            <div
              style={{
                color: c.accent,
                wordBreak: "break-all",
                cursor: "pointer",
                fontSize: 11,
              }}
            >
              {videoType === "url"
                ? videoUrl || "Enter URL above"
                : "Upload to get link"}
            </div>
          </div>
        )}
        <div style={{ borderTop: `1px solid ${c.divider}`, paddingTop: 10 }}>
          <div
            style={{
              fontSize: 12,
              color: c.textSub,
              fontFamily: FF,
              marginBottom: 5,
            }}
          >
            <span style={{ fontWeight: 600, color: c.textPrimary }}>
              {videoType === "url" ? "Source: " : "Filename: "}
            </span>
            {videoType === "url"
              ? videoUrl
                ? "URL"
                : "—"
              : (file?.name ?? "—")}
          </div>
          <div style={{ fontSize: 12, color: c.textSub, fontFamily: FF }}>
            <span style={{ fontWeight: 600, color: c.textPrimary }}>
              Size:{" "}
            </span>
            {file
              ? `${(file.size / 1024 / 1024).toFixed(1)} MB`
              : videoType === "url" && videoUrl
                ? "External"
                : "—"}
          </div>
        </div>
      </div>
    </div>
  </div>
);

/* ─────────────────── STEP 2: VIDEO ELEMENTS ─────────────────── */
const StepElements = ({ c }) => {
  const [modal, setModal] = useState(null);
  const [subtitles, setSubtitles] = useState([]);
  const [endScreen, setEndScreen] = useState(null);
  const [cards, setCards] = useState([]);

  const ELEMS = [
    {
      key: "subtitle",
      label: "Add subtitles",
      sub: "Help more people discover your video by adding subtitles in more languages.",
      Icon: FileText,
      badge: subtitles.length > 0 ? `${subtitles.length} added` : null,
    },
    {
      key: "endscreen",
      label: "Add an end screen",
      sub: "Promote relevant content at the end of your video.",
      Icon: Video,
      badge: endScreen ? "1 template" : null,
    },
    {
      key: "cards",
      label: "Add cards",
      sub: "Promote related content during your video.",
      Icon: Link,
      badge:
        cards.length > 0
          ? `${cards.length} card${cards.length > 1 ? "s" : ""}`
          : null,
    },
  ];

  return (
    <>
      {modal === "subtitle" && (
        <SubtitleModal
          onClose={() => setModal(null)}
          onSave={(d) => setSubtitles((p) => [...p, d])}
          c={c}
        />
      )}
      {modal === "endscreen" && (
        <EndScreenModal
          onClose={() => setModal(null)}
          onSave={(d) => setEndScreen(d)}
          c={c}
        />
      )}
      {modal === "cards" && (
        <CardsModal
          onClose={() => setModal(null)}
          onSave={(d) => setCards((p) => [...p, d])}
          c={c}
        />
      )}

      <SecTitle
        title="Video elements"
        subtitle="Add subtitles and end screen elements to enhance your lecture"
        c={c}
      />

      <div
        style={{
          border: `1px solid ${c.cardBorder}`,
          borderRadius: 4,
          overflow: "hidden",
        }}
      >
        {ELEMS.map(({ key, label, sub, Icon, badge }, i) => (
          <div
            key={key}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "18px 22px",
              borderBottom:
                i < ELEMS.length - 1 ? `1px solid ${c.divider}` : "none",
              background: c.cardBg,
            }}
          >
            <div style={{ display: "flex", alignItems: "flex-start", gap: 14 }}>
              <div
                style={{
                  width: 38,
                  height: 38,
                  background: c.zeroBg,
                  border: `1px solid ${c.divider}`,
                  borderRadius: 4,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                }}
              >
                <Icon size={17} color={c.textSub} />
              </div>
              <div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                    marginBottom: 3,
                  }}
                >
                  <div
                    style={{
                      fontSize: 14,
                      fontWeight: 500,
                      color: c.textPrimary,
                      fontFamily: FF,
                    }}
                  >
                    {label}
                  </div>
                  {badge && (
                    <span
                      style={{
                        fontSize: 11,
                        fontWeight: 500,
                        padding: "2px 7px",
                        borderRadius: 3,
                        background: c.accentBg,
                        color: c.accent,
                        fontFamily: FF,
                      }}
                    >
                      ✓ {badge}
                    </span>
                  )}
                </div>
                <div
                  style={{
                    fontSize: 13,
                    color: c.textSub,
                    fontFamily: FF,
                    maxWidth: 380,
                  }}
                >
                  {sub}
                </div>
              </div>
            </div>
            <button
              onClick={() => setModal(key)}
              style={{
                ...oBtn(c),
                whiteSpace: "nowrap",
                flexShrink: 0,
                color: c.accent,
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.background = c.accentLight)
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.background = c.cardBg)
              }
            >
              + Add
            </button>
          </div>
        ))}
      </div>

      {(subtitles.length > 0 || endScreen || cards.length > 0) && (
        <div
          style={{
            marginTop: 16,
            padding: "14px 18px",
            background: c.zeroBg,
            borderRadius: 4,
            border: `1px solid ${c.cardBorder}`,
          }}
        >
          <div
            style={{
              fontSize: 11,
              fontWeight: 600,
              color: c.textSub,
              fontFamily: FF,
              marginBottom: 10,
              textTransform: "uppercase",
              letterSpacing: ".5px",
            }}
          >
            Added Elements
          </div>
          {subtitles.map((s, i) => (
            <div
              key={i}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: 7,
              }}
            >
              <span
                style={{ fontSize: 13, color: c.textPrimary, fontFamily: FF }}
              >
                📄 Subtitle ({s.lang}){s.file ? ` — ${s.file.name}` : ""}
              </span>
              <X
                size={13}
                color={c.textSub}
                style={{ cursor: "pointer" }}
                onClick={() => setSubtitles((p) => p.filter((_, j) => j !== i))}
              />
            </div>
          ))}
          {endScreen && (
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: 7,
              }}
            >
              <span
                style={{ fontSize: 13, color: c.textPrimary, fontFamily: FF }}
              >
                🖥️ End screen — {endScreen}
              </span>
              <X
                size={13}
                color={c.textSub}
                style={{ cursor: "pointer" }}
                onClick={() => setEndScreen(null)}
              />
            </div>
          )}
          {cards.map((card, i) => (
            <div
              key={i}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: 7,
              }}
            >
              <span
                style={{ fontSize: 13, color: c.textPrimary, fontFamily: FF }}
              >
                🔗 {card.type === "video" ? "Video" : "Link"} card —{" "}
                {card.label || card.url}
              </span>
              <X
                size={13}
                color={c.textSub}
                style={{ cursor: "pointer" }}
                onClick={() => setCards((p) => p.filter((_, j) => j !== i))}
              />
            </div>
          ))}
        </div>
      )}
    </>
  );
};

/* ─────────────────── STEP 3: CHECKS ─────────────────── */
const StepChecks = ({ c }) => (
  <div>
    <SecTitle
      title="Checks"
      subtitle="We check for issues that might impact your ability to monetize or distribute this video."
      c={c}
    />
    <div
      style={{
        border: `1px solid ${c.cardBorder}`,
        borderRadius: 4,
        overflow: "hidden",
      }}
    >
      {[
        { label: "Copyright check", status: "No issues found" },
        { label: "Ad suitability", status: "Suitable for most advertisers" },
        { label: "Community Guidelines", status: "No violations detected" },
      ].map((item, i, arr) => (
        <div
          key={item.label}
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "16px 22px",
            borderBottom:
              i < arr.length - 1 ? `1px solid ${c.divider}` : "none",
            background: c.cardBg,
          }}
        >
          <div>
            <div
              style={{
                fontSize: 14,
                fontWeight: 500,
                color: c.textPrimary,
                fontFamily: FF,
                marginBottom: 2,
              }}
            >
              {item.label}
            </div>
            <div style={{ fontSize: 13, color: c.textSub, fontFamily: FF }}>
              {item.status}
            </div>
          </div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 6,
              color: c.successColor,
              fontSize: 13,
              fontWeight: 500,
              fontFamily: FF,
            }}
          >
            <Check size={15} color={c.successColor} strokeWidth={2.5} />
            No issues
          </div>
        </div>
      ))}
    </div>
  </div>
);

/* ─────────────────── STEP 4: VISIBILITY ─────────────────── */
const StepVisibility = ({ visibility, setVisibility, c }) => (
  <div>
    <SecTitle
      title="Visibility"
      subtitle="Choose when to publish and who can see your video"
      c={c}
    />
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      <VisCard
        value="public"
        selected={visibility === "public"}
        onChange={setVisibility}
        icon={Globe}
        title="Public"
        desc="Everyone can watch your video"
        c={c}
      />
      <VisCard
        value="unlisted"
        selected={visibility === "unlisted"}
        onChange={setVisibility}
        icon={Eye}
        title="Unlisted"
        desc="Anyone with the video link can watch your video"
        c={c}
      />
      <VisCard
        value="private"
        selected={visibility === "private"}
        onChange={setVisibility}
        icon={Lock}
        title="Private"
        desc="Only enrolled batch students can view"
        c={c}
      />
    </div>
  </div>
);

/* ─────────────────── ADD COURSE FORM ─────────────────── */
const AddCourseForm = ({ onSave, onClose, c }) => {
  const [name, setName] = useState("");
  return (
    <div>
      <label style={lbl(c)}>Course Name</label>
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && name.trim()) onSave(name.trim());
        }}
        placeholder="e.g. Advanced React Patterns"
        style={{ ...inp(c), marginBottom: 16 }}
        autoFocus
        onFocus={(e) => (e.target.style.borderColor = c.accent)}
        onBlur={(e) => (e.target.style.borderColor = c.inputBorder)}
      />
      <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
        <button onClick={onClose} style={oBtn(c)}>
          Cancel
        </button>
        <button
          disabled={!name.trim()}
          onClick={() => name.trim() && onSave(name.trim())}
          style={{
            ...pBtn(),
            opacity: name.trim() ? 1 : 0.5,
            cursor: name.trim() ? "pointer" : "not-allowed",
          }}
        >
          Add Course
        </button>
      </div>
    </div>
  );
};

/* ─────────────────── DRAFT TOAST ─────────────────── */
const DraftToast = ({ message, c }) => {
  if (!message) return null;
  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "6px 14px",
        borderRadius: 20,
        background: c.draftBg,
        border: `1px solid ${c.draftBorder}`,
        color: c.draftColor,
        fontSize: 12,
        fontWeight: 600,
        fontFamily: FF,
      }}
    >
      <Save size={12} /> {message}
    </div>
  );
};

/* ─────────────────── MAIN UPLOAD PANEL ─────────────────── */
const UploadVideoPanel = ({ t, isDark }) => {
  const c = getColors(isDark);

  const [showCourseModal, setShowCourseModal] = useState(false);

  const [file, setFile] = useState(null);
  const [title, setTitle] = useState("");
  const [shortDesc, setShortDesc] = useState("");
  const [batchId, setBatchId] = useState("default_segment");
  const [videoType, setVideoType] = useState("upload");
  const [videoUrl, setVideoUrl] = useState("");
  const [tags, setTags] = useState([]);
  const [audience, setAudience] = useState("not-kids");
  const [ageRestrict, setAgeRestrict] = useState(false);
  const [visibility, setVisibility] = useState("public");
  const [category, setCategory] = useState("");
  const [language, setLanguage] = useState("English");
  const [course, setCourse] = useState("");

  const [activeStep, setActiveStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [draftLoading, setDraftLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [draftMsg, setDraftMsg] = useState("");
  const [refreshKey, setRefreshKey] = useState(0);

  const [batches, setBatches] = useState([]);
  const [courseOptions, setCourseOptions] = useState([]);
  const [coursesLoading, setCoursesLoading] = useState(false);
  const [quota, setQuota] = useState(null);
  const [upgradeConfig, setUpgradeConfig] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const res = await videoService.getTrainerBatches();
        setBatches(res.data || []);
      } catch (err) {
        console.error("Failed to load batches", err);
      }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      setCoursesLoading(true);
      try {
        const res = await courseService.getMyCourses();
        const raw = res.data || [];
        setCourseOptions(
          raw.map((c) => ({
            value: String(c.id),
            label: c.title ?? c.name ?? `Course ${c.id}`,
            subtitle: c.category ?? "",
          })),
        );
      } catch (err) {
        console.error("Failed to load courses", err);
        setCourseOptions([]);
      } finally {
        setCoursesLoading(false);
      }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const res = await videoService.getUploadQuota();
        setQuota(res.data);
      } catch (err) {
        console.error("Failed to load upload quota", err);
      }
    })();
  }, [refreshKey]);

  /* ── Batch options: prepend "Default Segment" ── */

  /* ── Batch options: prepend "Default Segment" ── */
  const batchOptions = [
    { value: "default_segment", label: "Default Segment (No Batch)" },
    ...batches.map((b) => ({
      value: String(b.id),
      label: `${b.name || "Batch"} (ID: ${b.id})`,
    })),
  ];

  /* ── Shared payload builder ── */
  const buildMeta = (status) => ({
    tags,
    category,
    language,
    visibility,
    audience,
    ageRestrict,
    course,
    status,
  });

  /* ── Reset form ── */
  const resetForm = () => {
    setFile(null);
    setTitle("");
    setShortDesc("");
    setBatchId("default_segment");
    setVideoUrl("");
    setTags([]);
    setCategory("");
    setCourse("");
    setAgeRestrict(false);
    setVisibility("public");
    setAudience("not-kids");
    setActiveStep(1);
  };

  /* ── PUBLISH ── */
  const handlePublish = async () => {
    if (videoType === "upload" && !file) {
      setMessage("❌ Select a video file");
      return;
    }
    if (videoType === "url" && !videoUrl.trim()) {
      setMessage("❌ Enter a video URL");
      return;
    }
    if (!title.trim()) {
      setMessage("❌ Title is required");
      return;
    }

    const resolvedBatch = resolveBatchId(batchId);
    const meta = buildMeta("published");

    try {
      setLoading(true);
      setMessage("");
      if (videoType === "upload") {
        await videoService.uploadVideo(
          file,
          title,
          shortDesc,
          resolvedBatch,
          meta,
        );
      } else {
        const parsed = parseVideoUrl(videoUrl);
        await videoService.uploadVideoUrl(
          parsed ? parsed.url : videoUrl,
          title,
          shortDesc,
          resolvedBatch,
          {
            ...meta,
            videoSourceType: parsed?.type ?? "video",
            originalUrl: videoUrl,
          },
        );
      }
      setMessage("✅ Lecture published successfully!");
      setRefreshKey((p) => p + 1);
      resetForm();
    } catch (err) {
      const planError = parsePlanError(err);
      if (planError) {
        setUpgradeConfig({
          currentPlan: quota?.tier || "free",
          featureLabel: planError.message,
        });
      } else {
        setMessage("❌ Upload failed (check batch assignment)");
      }
    } finally {
      setLoading(false);
    }
  };

  /* ── SAVE AS DRAFT ── */
  const handleDraft = async () => {
    const hasContent = videoType === "upload" ? !!file : !!videoUrl.trim();
    if (!hasContent) {
      setDraftMsg("⚠️ Add a video or URL first");
      setTimeout(() => setDraftMsg(""), 3000);
      return;
    }

    const resolvedBatch = resolveBatchId(batchId);
    const meta = buildMeta("draft");

    try {
      setDraftLoading(true);
      setDraftMsg("");
      if (videoType === "upload") {
        await videoService.uploadVideo(
          file,
          title || (file ? file.name : "Untitled Draft"),
          shortDesc,
          resolvedBatch,
          meta,
        );
      } else {
        const parsed = parseVideoUrl(videoUrl);
        await videoService.uploadVideoUrl(
          parsed ? parsed.url : videoUrl,
          title || "Untitled Draft",
          shortDesc,
          resolvedBatch,
          {
            ...meta,
            videoSourceType: parsed?.type ?? "video",
            originalUrl: videoUrl,
          },
        );
      }
      setDraftMsg("✏️ Draft saved successfully");
      setRefreshKey((p) => p + 1);
    } catch (err) {
      const planError = parsePlanError(err);
      if (planError) {
        setUpgradeConfig({
          currentPlan: quota?.tier || "free",
          featureLabel: planError.message,
        });
      } else {
        setDraftMsg("⚠️ Could not save draft");
      }
    } finally {
      setDraftLoading(false);
      setTimeout(() => setDraftMsg(""), 4000);
    }
  };

  return (
    <>
      {showCourseModal && (
        <Modal
          title="Add New Course"
          onClose={() => setShowCourseModal(false)}
          c={c}
        >
          <p
            style={{
              fontSize: 13,
              color: c.textSub,
              fontFamily: FF,
              margin: "0 0 14px",
            }}
          >
            Enter a name for the new course.
          </p>
          <AddCourseForm
            onSave={(newName) => {
              const newOpt = { value: newName, label: newName, subtitle: "" };
              setCourseOptions((prev) => [...prev, newOpt]);
              setCourse(newName);
              setShowCourseModal(false);
            }}
            onClose={() => setShowCourseModal(false)}
            c={c}
          />
        </Modal>
      )}

      {/* Step header */}
      <div
        style={{
          background: c.cardBg,
          border: `1px solid ${c.cardBorder}`,
          borderRadius: RADIUS.standardCard,
          padding: "18px 28px 14px",
          marginBottom: 16,
          boxShadow: c.shadow,
          boxSizing: "border-box",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            marginBottom: 18,
          }}
        >
          <div
            style={{
              fontSize: 17,
              fontWeight: 600,
              color: c.textPrimary,
              fontFamily: FF,
            }}
          >
            {file
              ? title || file.name
              : videoUrl
                ? title || "Video URL"
                : "Publish Lecture"}
          </div>
          <div style={{ fontSize: 12, color: c.textSub, fontFamily: FF }}>
            {file || videoUrl ? "Saved as private" : "Not saved"}
          </div>
        </div>
        {quota && (
          <div
            style={{
              marginBottom: 14,
              display: "flex",
              flexDirection: "column",
              gap: 8,
            }}
          >
            <UsageBadge
              storageUsedBytes={quota.storageUsedBytes}
              storageCapBytes={quota.storageCapBytes}
              label={`${quota.tier?.toUpperCase() || ""} · ${quota.videoCount}/${quota.maxVideoCount} videos`}
              c={c}
            />
            <div style={{ fontSize: 11, color: c.textSub, fontFamily: FF }}>
              Max size per video upload:{" "}
              <strong style={{ color: c.textPrimary }}>
                {quota.maxVideoSizeBytes
                  ? `${(quota.maxVideoSizeBytes / 1024 / 1024).toFixed(0)} MB`
                  : "—"}
              </strong>
            </div>
          </div>
        )}
        <StepProgressBar
          activeStep={activeStep}
          setActiveStep={setActiveStep}
          c={c}
        />
      </div>

      {/* Step content */}
      <div
        className="uv-step-content"
        style={{
          background: c.cardBg,
          border: `1px solid ${c.cardBorder}`,
          borderRadius: RADIUS.standardCard,
          padding: 28,
          marginBottom: 14,
          boxShadow: c.shadow,
          boxSizing: "border-box",
        }}
      >
        {activeStep === 1 && (
          <StepDetails
            file={file}
            setFile={setFile}
            title={title}
            setTitle={setTitle}
            videoUrl={videoUrl}
            setVideoUrl={setVideoUrl}
            videoType={videoType}
            setVideoType={setVideoType}
            shortDesc={shortDesc}
            setShortDesc={setShortDesc}
            batchId={batchId}
            setBatchId={setBatchId}
            batchOptions={batchOptions}
            tags={tags}
            setTags={setTags}
            category={category}
            setCategory={setCategory}
            language={language}
            setLanguage={setLanguage}
            course={course}
            setCourse={setCourse}
            courseOptions={courseOptions}
            coursesLoading={coursesLoading}
            audience={audience}
            setAudience={setAudience}
            ageRestrict={ageRestrict}
            setAgeRestrict={setAgeRestrict}
            setShowCourseModal={setShowCourseModal}
            c={c}
          />
        )}
        {activeStep === 2 && <StepElements c={c} />}
        {activeStep === 3 && <StepChecks c={c} />}
        {activeStep === 4 && (
          <StepVisibility
            visibility={visibility}
            setVisibility={setVisibility}
            c={c}
          />
        )}
      </div>

      {/* ── Bottom action bar ── */}
      <div
        style={{
          background: c.cardBg,
          border: `1px solid ${c.cardBorder}`,
          borderRadius: RADIUS.standardCard,
          padding: "12px 22px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexWrap: "wrap",
          gap: 10,
          boxShadow: c.shadow,
          boxSizing: "border-box",
        }}
      >
        {/* Left: status messages */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 12,
            flexWrap: "wrap",
          }}
        >
          {draftMsg && <DraftToast message={draftMsg} c={c} />}
          {message && !draftMsg && (
            <span
              style={{
                fontSize: 13,
                fontFamily: FF,
                color: message.startsWith("✅") ? c.successColor : c.errorColor,
              }}
            >
              {message}
            </span>
          )}
        </div>

        {/* Right: action buttons */}
        <div
          style={{
            display: "flex",
            gap: 10,
            alignItems: "center",
            flexWrap: "wrap",
          }}
        >
          {activeStep > 1 && (
            <button onClick={() => setActiveStep((p) => p - 1)} style={oBtn(c)}>
              Back
            </button>
          )}

          {/* Save as Draft */}
          <button
            onClick={handleDraft}
            disabled={draftLoading}
            style={{
              ...oBtn(c),
              display: "flex",
              alignItems: "center",
              gap: 6,
              borderColor: c.draftBorder,
              color: c.draftColor,
              background: c.draftBg,
              opacity: draftLoading ? 0.6 : 1,
              cursor: draftLoading ? "not-allowed" : "pointer",
            }}
          >
            <Save size={13} />
            {draftLoading ? "Saving…" : "Save Draft"}
          </button>

          {activeStep < 4 ? (
            <button
              onClick={() => setActiveStep((p) => p + 1)}
              style={{
                ...pBtn(),
                display: "flex",
                alignItems: "center",
                gap: 6,
              }}
            >
              Next
            </button>
          ) : (
            <button
              onClick={handlePublish}
              disabled={loading}
              style={{
                ...pBtn(),
                display: "flex",
                alignItems: "center",
                gap: 6,
                opacity: loading ? 0.6 : 1,
              }}
            >
              <Send size={13} />
              {loading ? "Publishing..." : "Publish"}
            </button>
          )}
        </div>
      </div>

      {/* Video list below */}
      <div style={{ marginTop: 18 }}>
        <VideoList refreshKey={refreshKey} trainerMode={true} />
      </div>
      {upgradeConfig && (
        <UpgradeModal
          isOpen={!!upgradeConfig}
          onClose={() => setUpgradeConfig(null)}
          planType="individual"
          userId={getAuthTokenUserId()}
          currentPlan={upgradeConfig.currentPlan}
          availableTargetPlans={["pro", "premium"]}
          featureLabel={upgradeConfig.featureLabel}
          onSuccess={() => {
            setUpgradeConfig(null);
            setRefreshKey((p) => p + 1);
          }}
        />
      )}
    </>
  );
};

/* ─────────────────── TAB BAR — reuses the Golden Reference's pill/chip
   language (RADIUS.pill, card surface, ACCENT_PURPLE active state) instead
   of a page-specific underline tab bar. ─────────────────── */
const TabBar = ({ activeTab, setActiveTab, c }) => (
  <div
    className="uv-tab-bar"
    style={{
      display: "flex",
      flexWrap: "wrap",
      gap: 8,
      background: c.cardBg,
      border: `1px solid ${c.cardBorder}`,
      borderRadius: RADIUS.standardCard,
      padding: 8,
      marginBottom: 18,
      boxShadow: c.shadow,
      boxSizing: "border-box",
    }}
  >
    {TABS.map(({ key, label, icon: Icon }) => {
      const isActive = activeTab === key;
      return (
        <button
          key={key}
          onClick={() => setActiveTab(key)}
          style={{
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 7,
            padding: "9px 16px",
            border: `1px solid ${isActive ? "rgba(124,58,237,0.3)" : "transparent"}`,
            borderRadius: RADIUS.pill,
            cursor: "pointer",
            fontFamily: FF,
            fontSize: 12,
            fontWeight: isActive ? FONT_WEIGHT.bold : FONT_WEIGHT.medium || 500,
            background: isActive ? "rgba(124,58,237,0.08)" : "transparent",
            color: isActive ? ACCENT_PURPLE.base : c.textSub,
            transition: "all .15s",
            flex: "1 1 auto",
            whiteSpace: "nowrap",
          }}
        >
          <Icon size={15} />
          {label}
        </button>
      );
    })}
  </div>
);

/* ─────────────────── RESPONSIVE STYLES — page-scoped rules that collapse
   the form's multi-column layouts down to a single column on tablets and
   phones. Breakpoints mirror the Golden Reference's own grid behaviour. ─── */
const UploadVideosResponsiveStyles = () => (
  <style>{`
    .uv-two-col { align-items: flex-start; }
    @media (max-width: 1024px) {
      .uv-two-col { flex-direction: column; }
      .uv-side-panel { width: 100% !important; }
    }
    @media (max-width: 640px) {
      .uv-form-grid-2 { grid-template-columns: 1fr !important; }
      .uv-tab-bar { padding: 6px; }
      .uv-tab-bar button { flex: 1 1 100% !important; }
      .uv-step-content { padding: 18px !important; }
      .uv-step-progress { padding: 0 4px; justify-content: flex-start !important; }
    }
    @media (max-width: 480px) {
      .uv-two-col { gap: 20px !important; }
      .uv-step-content { padding: 14px !important; }
    }
  `}</style>
);

/* ─────────────────── MAIN PAGE ─────────────────── */
const UploadVideos = () => {
  // ── theme detection — identical pattern to the Trainer Dashboard
  // (Golden Reference), watching the <html> element instead of relying on
  // a page-local theme hook. ──────────────────────────────────────────────
  const [isDark, setIsDark] = useState(
    () =>
      typeof document !== "undefined" &&
      (document.documentElement.classList.contains("dark") ||
        document.documentElement.getAttribute("data-theme") === "dark"),
  );
  useEffect(() => {
    const obs = new MutationObserver(() => {
      setIsDark(
        document.documentElement.classList.contains("dark") ||
          document.documentElement.getAttribute("data-theme") === "dark",
      );
    });
    obs.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class", "data-theme"],
    });
    return () => obs.disconnect();
  }, []);

  const t = isDark ? T.dark : T.light;
  const c = getColors(isDark);
  const [activeTab, setActiveTab] = useState("upload-video");

  const heroMeta = {
    "upload-video": {
      title: "Publish New Lecture",
      subtitle: "Upload recorded lectures for students.",
      icon: Video,
    },
    "upload-document": {
      title: "Upload Documents",
      subtitle: "Share study material and resources with students.",
      icon: FileText,
    },
    "create-quiz": {
      title: "Create Quiz",
      subtitle: "Build interactive quizzes for your batch.",
      icon: ClipboardEdit,
    },
    "create-assignment": {
      title: "Create Assignment",
      subtitle: "Set assignments and track submissions.",
      icon: BookOpen,
    },
  }[activeTab] || {
    title: "Trainer Studio",
    subtitle: "",
    icon: Video,
  };

  const renderPanel = () => {
    switch (activeTab) {
      case "upload-video":
        return <UploadVideoPanel t={t} isDark={isDark} />;
      case "upload-document":
        return <UploadDocuments />;
      case "create-quiz":
        return <CreateQuiz />;
      case "create-assignment":
        return <CreateAssignments />;
      default:
        return null;
    }
  };

  const HeroIcon = heroMeta.icon;

  return (
    <PageContainer
      mode={isDark ? "dark" : "light"}
      pageBg={t.pageBg}
      textColor={t.text}
    >
      <UploadVideosResponsiveStyles />

      {/* ═══ HERO — shared <Hero> component. Eyebrow / title / subtitle now
          use FONT_SIZE / FONT_WEIGHT / LINE_HEIGHT / LETTER_SPACING tokens
          — same set the Attendance page (Golden Reference) reads from —
          instead of hardcoded clamp()/px values. ═══ */}
      <Hero borderHero={t.borderHero}>
        <div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 6,
              marginBottom: 8,
            }}
          >
            <div
              style={{
                width: 6,
                height: 6,
                borderRadius: "50%",
                background: ACCENT_PURPLE.base,
              }}
            />
            <span
              style={{
                fontSize: FONT_SIZE.eyebrow,
                fontWeight: FONT_WEIGHT.bold,
                letterSpacing: LETTER_SPACING.eyebrowWide,
                textTransform: "uppercase",
                color: t.textSub,
                fontFamily: FONT_FAMILY,
              }}
            >
              Trainer Studio
            </span>
          </div>
          <h1
            style={{
              fontFamily: FONT_FAMILY,
              fontWeight: FONT_WEIGHT.heroTitle,
              fontSize: FONT_SIZE.heroTitle,
              color: ACCENT_PURPLE.base,
              margin: "0 0 6px",
              lineHeight: LINE_HEIGHT.heroTitle,
              letterSpacing: LETTER_SPACING.heroTitle,
            }}
          >
            {heroMeta.title}
          </h1>
          <p
            style={{
              fontSize: FONT_SIZE.bodySmall,
              color: t.textSub,
              margin: 0,
              fontWeight: FONT_WEIGHT.medium,
              fontFamily: FONT_FAMILY,
            }}
          >
            {heroMeta.subtitle}
          </p>
        </div>

        <div className="hero-badges">
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              background: t.iconBg,
              border: `1px solid ${t.iconBorder}`,
              borderRadius: RADIUS.chip,
              padding: "8px 16px",
              width: 34,
              height: 34,
              boxSizing: "content-box",
            }}
          >
            <HeroIcon size={16} color={t.text} />
          </div>
        </div>
      </Hero>

      <TabBar activeTab={activeTab} setActiveTab={setActiveTab} c={c} />
      {renderPanel()}
    </PageContainer>
  );
};

export default UploadVideos;
